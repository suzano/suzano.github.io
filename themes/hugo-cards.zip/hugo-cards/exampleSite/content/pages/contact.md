---
layout: page
title: Contact
permalink: /contact/
---

Visit [my site](https://bool.netlify.com)

Insert your contact details or a contact form here.

