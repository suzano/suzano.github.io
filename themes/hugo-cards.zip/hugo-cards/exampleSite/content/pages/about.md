---
layout: page
title: About
permalink: /about/
---




Hugo cards is a Bootstrap based theme ported from the Jekyll theme [Webjeda-cards](https://webjeda.com/cards/). Any Bootstrap element can be used in the theme.

For more themes, visit [Hugo Themes](https://themes.gohugo.io/)

**Does the theme deserve a star?**

<!-- Place this tag where you want the button to render. -->
<a class="github-button" href="https://github.com/bul-ikana/hugo-cards" data-icon="octicon-star" data-size="large" data-show-count="true" aria-label="Star bul-ikana/hugo-cards on GitHub">Star</a>
<!-- Place this tag in your head or just before your close body tag. -->
<script async defer src="https://buttons.github.io/buttons.js"></script>