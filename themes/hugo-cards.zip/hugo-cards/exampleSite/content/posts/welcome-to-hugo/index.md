---
title:  "Welcome to Hugox!"
date:   2016-06-13 10:51:47 +0530
img: "image-1.png"
categories: [one, two]
author: "Hugo Aguirre"
profile:
  attrs:
    - key: Name
      val: Stuart
    - key: Likes
      val: Playing guitar
---

Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris erat augue, eleifend nec est quis, iaculis suscipit lacus. In convallis ut mi ac volutpat. Integer feugiat lacinia purus, at condimentum enim tempus vitae. Fusce tempus tortor nibh, ut mollis sapien pulvinar at. Nam nec tortor ante. Phasellus lorem elit, placerat sit amet ligula ac, fermentum vulputate nibh. Quisque sed dapibus risus. Quisque sagittis iaculis maximus. Mauris lorem ligula, commodo in ullamcorper et, mollis ut dui.

Integer ut turpis metus. Curabitur purus orci, sagittis non ultrices ac, elementum ut diam. Suspendisse fringilla dolor id sapien tincidunt, vitae tempor enim tempus. Ut quis varius tortor, ut molestie ante. Curabitur maximus quis nibh quis lacinia. Nullam ante nunc, mollis sed nibh quis, sagittis semper lectus. Morbi quis enim nibh. Vestibulum justo sem, placerat vitae cursus vel, hendrerit vitae nibh. Mauris id metus non lorem volutpat varius. Fusce dui lectus, imperdiet at felis at, tincidunt dapibus enim. Ut porttitor at magna molestie faucibus. Etiam sed dignissim lectus. Praesent interdum vulputate diam, non iaculis libero fringilla sit amet. Nunc dignissim vel ipsum sed tincidunt. Nullam id sapien quam.
